from __future__ import absolute_import
from .rpi_rf import RFDevice


__version__ = '0.9.6'
